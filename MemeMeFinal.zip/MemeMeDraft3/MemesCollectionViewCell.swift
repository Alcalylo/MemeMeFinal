//
//  MemesCollectionViewCell.swift
//  MemeMeDraft3
//
//  Created by ALCALY LO on 1/22/18.
//  Copyright © 2018 ALCALY LO. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeImageView: UIImageView!
    
    
}
